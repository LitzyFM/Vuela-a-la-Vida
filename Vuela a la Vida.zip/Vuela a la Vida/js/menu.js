const menus = document.querySelector('.menus');
const menu = document.querySelector('.menu-navegacion'); 

console.log(menu)
console.log(menus)


menus.addEventListener('click', ()=>{
    menu.classList.toggle("spread")
})


